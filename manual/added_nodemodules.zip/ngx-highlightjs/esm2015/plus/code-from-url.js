import { Pipe } from '@angular/core';
import { CodeLoader } from './code-loader';
export class CodeFromUrlPipe {
    constructor(_loader) {
        this._loader = _loader;
    }
    transform(url) {
        return this._loader.getCodeFromUrl(url);
    }
}
CodeFromUrlPipe.decorators = [
    { type: Pipe, args: [{
                name: 'codeFromUrl'
            },] }
];
CodeFromUrlPipe.ctorParameters = () => [
    { type: CodeLoader }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29kZS1mcm9tLXVybC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL25neC1oaWdobGlnaHRqcy9wbHVzL3NyYy9jb2RlLWZyb20tdXJsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxJQUFJLEVBQWlCLE1BQU0sZUFBZSxDQUFDO0FBRXBELE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFLM0MsTUFBTSxPQUFPLGVBQWU7SUFFMUIsWUFBb0IsT0FBbUI7UUFBbkIsWUFBTyxHQUFQLE9BQU8sQ0FBWTtJQUN2QyxDQUFDO0lBRUQsU0FBUyxDQUFDLEdBQVc7UUFDbkIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUMxQyxDQUFDOzs7WUFWRixJQUFJLFNBQUM7Z0JBQ0osSUFBSSxFQUFFLGFBQWE7YUFDcEI7OztZQUpRLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQaXBlLCBQaXBlVHJhbnNmb3JtIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBDb2RlTG9hZGVyIH0gZnJvbSAnLi9jb2RlLWxvYWRlcic7XG5cbkBQaXBlKHtcbiAgbmFtZTogJ2NvZGVGcm9tVXJsJ1xufSlcbmV4cG9ydCBjbGFzcyBDb2RlRnJvbVVybFBpcGUgaW1wbGVtZW50cyBQaXBlVHJhbnNmb3JtIHtcblxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9sb2FkZXI6IENvZGVMb2FkZXIpIHtcbiAgfVxuXG4gIHRyYW5zZm9ybSh1cmw6IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgcmV0dXJuIHRoaXMuX2xvYWRlci5nZXRDb2RlRnJvbVVybCh1cmwpO1xuICB9XG59XG4iXX0=