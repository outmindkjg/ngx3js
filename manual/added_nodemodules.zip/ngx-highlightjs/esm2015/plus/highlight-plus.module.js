import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { HighlightModule } from 'ngx-highlightjs';
// Uncomment the following line for development
// import { HighlightModule } from '../../src/public-api';
import { GistFilePipe, GistDirective } from './gist';
import { CodeFromUrlPipe } from './code-from-url';
export class HighlightPlusModule {
}
HighlightPlusModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    HighlightModule,
                    HttpClientModule
                ],
                declarations: [
                    GistDirective,
                    GistFilePipe,
                    CodeFromUrlPipe
                ],
                exports: [
                    HighlightModule,
                    GistDirective,
                    GistFilePipe,
                    CodeFromUrlPipe
                ]
            },] }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGlnaGxpZ2h0LXBsdXMubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcHJvamVjdHMvbmd4LWhpZ2hsaWdodGpzL3BsdXMvc3JjL2hpZ2hsaWdodC1wbHVzLm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3pDLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBQ3hELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUNsRCwrQ0FBK0M7QUFDL0MsMERBQTBEO0FBQzFELE9BQU8sRUFBRSxZQUFZLEVBQUUsYUFBYSxFQUFFLE1BQU0sUUFBUSxDQUFDO0FBQ3JELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQW1CbEQsTUFBTSxPQUFPLG1CQUFtQjs7O1lBakIvQixRQUFRLFNBQUM7Z0JBQ1IsT0FBTyxFQUFFO29CQUNQLGVBQWU7b0JBQ2YsZ0JBQWdCO2lCQUNqQjtnQkFDRCxZQUFZLEVBQUU7b0JBQ1osYUFBYTtvQkFDYixZQUFZO29CQUNaLGVBQWU7aUJBQ2hCO2dCQUNELE9BQU8sRUFBRTtvQkFDUCxlQUFlO29CQUNmLGFBQWE7b0JBQ2IsWUFBWTtvQkFDWixlQUFlO2lCQUNoQjthQUNGIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEh0dHBDbGllbnRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBIaWdobGlnaHRNb2R1bGUgfSBmcm9tICduZ3gtaGlnaGxpZ2h0anMnO1xuLy8gVW5jb21tZW50IHRoZSBmb2xsb3dpbmcgbGluZSBmb3IgZGV2ZWxvcG1lbnRcbi8vIGltcG9ydCB7IEhpZ2hsaWdodE1vZHVsZSB9IGZyb20gJy4uLy4uL3NyYy9wdWJsaWMtYXBpJztcbmltcG9ydCB7IEdpc3RGaWxlUGlwZSwgR2lzdERpcmVjdGl2ZSB9IGZyb20gJy4vZ2lzdCc7XG5pbXBvcnQgeyBDb2RlRnJvbVVybFBpcGUgfSBmcm9tICcuL2NvZGUtZnJvbS11cmwnO1xuXG5ATmdNb2R1bGUoe1xuICBpbXBvcnRzOiBbXG4gICAgSGlnaGxpZ2h0TW9kdWxlLFxuICAgIEh0dHBDbGllbnRNb2R1bGVcbiAgXSxcbiAgZGVjbGFyYXRpb25zOiBbXG4gICAgR2lzdERpcmVjdGl2ZSxcbiAgICBHaXN0RmlsZVBpcGUsXG4gICAgQ29kZUZyb21VcmxQaXBlXG4gIF0sXG4gIGV4cG9ydHM6IFtcbiAgICBIaWdobGlnaHRNb2R1bGUsXG4gICAgR2lzdERpcmVjdGl2ZSxcbiAgICBHaXN0RmlsZVBpcGUsXG4gICAgQ29kZUZyb21VcmxQaXBlXG4gIF1cbn0pXG5leHBvcnQgY2xhc3MgSGlnaGxpZ2h0UGx1c01vZHVsZSB7XG59XG4iXX0=