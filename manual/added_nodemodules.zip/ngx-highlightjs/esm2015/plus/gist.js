import { Directive, Pipe, Input, Output, EventEmitter } from '@angular/core';
import { CodeLoader } from './code-loader';
export class GistDirective {
    constructor(_loader) {
        this._loader = _loader;
        this.gistLoad = new EventEmitter();
    }
    set gist(value) {
        if (value) {
            this._loader.getCodeFromGist(value).subscribe((gist) => this.gistLoad.emit(gist));
        }
    }
}
GistDirective.decorators = [
    { type: Directive, args: [{
                selector: '[gist]'
            },] }
];
GistDirective.ctorParameters = () => [
    { type: CodeLoader }
];
GistDirective.propDecorators = {
    gist: [{ type: Input }],
    gistLoad: [{ type: Output }]
};
export class GistFilePipe {
    transform(gist, fileName) {
        return (gist && gist.files && gist.files[fileName]) ? gist.files[fileName].content : null;
    }
}
GistFilePipe.decorators = [
    { type: Pipe, args: [{
                name: 'gistFile'
            },] }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2lzdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL25neC1oaWdobGlnaHRqcy9wbHVzL3NyYy9naXN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQWlCLFlBQVksRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUM1RixPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBTTNDLE1BQU0sT0FBTyxhQUFhO0lBRXhCLFlBQW9CLE9BQW1CO1FBQW5CLFlBQU8sR0FBUCxPQUFPLENBQVk7UUFVN0IsYUFBUSxHQUFHLElBQUksWUFBWSxFQUFRLENBQUM7SUFUOUMsQ0FBQztJQUVELElBQ1ksSUFBSSxDQUFDLEtBQWE7UUFDNUIsSUFBSSxLQUFLLEVBQUU7WUFDVCxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFVLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7U0FDekY7SUFDSCxDQUFDOzs7WUFiRixTQUFTLFNBQUM7Z0JBQ1QsUUFBUSxFQUFFLFFBQVE7YUFDbkI7OztZQUxRLFVBQVU7OzttQkFXaEIsS0FBSzt1QkFPTCxNQUFNOztBQU1ULE1BQU0sT0FBTyxZQUFZO0lBQ3ZCLFNBQVMsQ0FBQyxJQUFVLEVBQUUsUUFBZ0I7UUFDcEMsT0FBTyxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztJQUM1RixDQUFDOzs7WUFORixJQUFJLFNBQUM7Z0JBQ0osSUFBSSxFQUFFLFVBQVU7YUFDakIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaXJlY3RpdmUsIFBpcGUsIElucHV0LCBPdXRwdXQsIFBpcGVUcmFuc2Zvcm0sIEV2ZW50RW1pdHRlciB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29kZUxvYWRlciB9IGZyb20gJy4vY29kZS1sb2FkZXInO1xuaW1wb3J0IHsgR2lzdCB9IGZyb20gJy4vZ2lzdC5tb2RlbCc7XG5cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ1tnaXN0XSdcbn0pXG5leHBvcnQgY2xhc3MgR2lzdERpcmVjdGl2ZSB7XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSBfbG9hZGVyOiBDb2RlTG9hZGVyKSB7XG4gIH1cblxuICBASW5wdXQoKVxuICBwcml2YXRlIHNldCBnaXN0KHZhbHVlOiBzdHJpbmcpIHtcbiAgICBpZiAodmFsdWUpIHtcbiAgICAgIHRoaXMuX2xvYWRlci5nZXRDb2RlRnJvbUdpc3QodmFsdWUpLnN1YnNjcmliZSgoZ2lzdDogR2lzdCkgPT4gdGhpcy5naXN0TG9hZC5lbWl0KGdpc3QpKTtcbiAgICB9XG4gIH1cblxuICBAT3V0cHV0KCkgZ2lzdExvYWQgPSBuZXcgRXZlbnRFbWl0dGVyPEdpc3Q+KCk7XG59XG5cbkBQaXBlKHtcbiAgbmFtZTogJ2dpc3RGaWxlJ1xufSlcbmV4cG9ydCBjbGFzcyBHaXN0RmlsZVBpcGUgaW1wbGVtZW50cyBQaXBlVHJhbnNmb3JtIHtcbiAgdHJhbnNmb3JtKGdpc3Q6IEdpc3QsIGZpbGVOYW1lOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgICByZXR1cm4gKGdpc3QgJiYgZ2lzdC5maWxlcyAmJiBnaXN0LmZpbGVzW2ZpbGVOYW1lXSkgPyBnaXN0LmZpbGVzW2ZpbGVOYW1lXS5jb250ZW50IDogbnVsbDtcbiAgfVxufVxuIl19