import { Inject, Injectable, Optional } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { EMPTY } from 'rxjs';
import { catchError, publishReplay, refCount } from 'rxjs/operators';
import { GIST_OPTIONS } from './gist.model';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common/http";
import * as i2 from "./gist.model";
export class CodeLoader {
    constructor(_http, _options) {
        this._http = _http;
        this._options = _options;
    }
    /**
     * Get plus code
     * @param id Gist ID
     */
    getCodeFromGist(id) {
        let params;
        if (this.isOAuthProvided()) {
            params = new HttpParams().set('client_id', this._options.clientId).set('client_secret', this._options.clientSecret);
        }
        return this.fetchFile(`https://api.github.com/gists/${id}`, { params, responseType: 'json' });
    }
    /**
     * Get code by URL
     * @param url File raw link
     */
    getCodeFromUrl(url) {
        return this.fetchFile(url, { responseType: 'text' });
    }
    /**
     * Check if OAuth option is provided
     */
    isOAuthProvided() {
        return !!this._options && !!this._options.clientId && !!this._options.clientSecret;
    }
    fetchFile(url, options) {
        // Check if URL is valid
        if (isUrl(url)) {
            return this._http.get(url, options).pipe(
            // Catch response
            publishReplay(1), refCount(), catchError((err) => {
                console.error('[NgxHighlight]: Unable to fetch the URL!', err.message);
                return EMPTY;
            }));
        }
        return EMPTY;
    }
}
CodeLoader.ɵprov = i0.ɵɵdefineInjectable({ factory: function CodeLoader_Factory() { return new CodeLoader(i0.ɵɵinject(i1.HttpClient), i0.ɵɵinject(i2.GIST_OPTIONS, 8)); }, token: CodeLoader, providedIn: "root" });
CodeLoader.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
CodeLoader.ctorParameters = () => [
    { type: HttpClient },
    { type: undefined, decorators: [{ type: Optional }, { type: Inject, args: [GIST_OPTIONS,] }] }
];
function isUrl(url) {
    const regExp = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
    return regExp.test(url);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29kZS1sb2FkZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9wcm9qZWN0cy9uZ3gtaGlnaGxpZ2h0anMvcGx1cy9zcmMvY29kZS1sb2FkZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsUUFBUSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzdELE9BQU8sRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFDOUQsT0FBTyxFQUFjLEtBQUssRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUN6QyxPQUFPLEVBQUUsVUFBVSxFQUFFLGFBQWEsRUFBRSxRQUFRLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUNyRSxPQUFPLEVBQVEsWUFBWSxFQUFlLE1BQU0sY0FBYyxDQUFDOzs7O0FBSy9ELE1BQU0sT0FBTyxVQUFVO0lBQ3JCLFlBQW9CLEtBQWlCLEVBQTRDLFFBQXFCO1FBQWxGLFVBQUssR0FBTCxLQUFLLENBQVk7UUFBNEMsYUFBUSxHQUFSLFFBQVEsQ0FBYTtJQUN0RyxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsZUFBZSxDQUFDLEVBQVU7UUFDeEIsSUFBSSxNQUFtQixDQUFDO1FBQ3hCLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRSxFQUFFO1lBQzFCLE1BQU0sR0FBRyxJQUFJLFVBQVUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDckg7UUFDRCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsZ0NBQWdDLEVBQUUsRUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDO0lBQ2hHLENBQUM7SUFFRDs7O09BR0c7SUFDSCxjQUFjLENBQUMsR0FBVztRQUN4QixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLEVBQUUsWUFBWSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUVEOztPQUVHO0lBQ0ssZUFBZTtRQUNyQixPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUM7SUFDckYsQ0FBQztJQUVPLFNBQVMsQ0FBQyxHQUFXLEVBQUUsT0FBWTtRQUN6Qyx3QkFBd0I7UUFDeEIsSUFBSSxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDZCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJO1lBQ3RDLGlCQUFpQjtZQUNqQixhQUFhLENBQUMsQ0FBQyxDQUFDLEVBQ2hCLFFBQVEsRUFBRSxFQUNWLFVBQVUsQ0FBQyxDQUFDLEdBQVUsRUFBRSxFQUFFO2dCQUN4QixPQUFPLENBQUMsS0FBSyxDQUFDLDBDQUEwQyxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDdkUsT0FBTyxLQUFLLENBQUM7WUFDZixDQUFDLENBQUMsQ0FDSCxDQUFDO1NBQ0g7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7Ozs7WUFoREYsVUFBVSxTQUFDO2dCQUNWLFVBQVUsRUFBRSxNQUFNO2FBQ25COzs7WUFQUSxVQUFVOzRDQVN1QixRQUFRLFlBQUksTUFBTSxTQUFDLFlBQVk7O0FBZ0R6RSxTQUFTLEtBQUssQ0FBQyxHQUFXO0lBQ3hCLE1BQU0sTUFBTSxHQUFHLG1GQUFtRixDQUFDO0lBQ25HLE9BQU8sTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUMxQixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0LCBJbmplY3RhYmxlLCBPcHRpb25hbCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cENsaWVudCwgSHR0cFBhcmFtcyB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IE9ic2VydmFibGUsIEVNUFRZIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBjYXRjaEVycm9yLCBwdWJsaXNoUmVwbGF5LCByZWZDb3VudCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IEdpc3QsIEdJU1RfT1BUSU9OUywgR2lzdE9wdGlvbnMgfSBmcm9tICcuL2dpc3QubW9kZWwnO1xuXG5ASW5qZWN0YWJsZSh7XG4gIHByb3ZpZGVkSW46ICdyb290J1xufSlcbmV4cG9ydCBjbGFzcyBDb2RlTG9hZGVyIHtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBfaHR0cDogSHR0cENsaWVudCwgQE9wdGlvbmFsKCkgQEluamVjdChHSVNUX09QVElPTlMpIHByaXZhdGUgX29wdGlvbnM6IEdpc3RPcHRpb25zKSB7XG4gIH1cblxuICAvKipcbiAgICogR2V0IHBsdXMgY29kZVxuICAgKiBAcGFyYW0gaWQgR2lzdCBJRFxuICAgKi9cbiAgZ2V0Q29kZUZyb21HaXN0KGlkOiBzdHJpbmcpOiBPYnNlcnZhYmxlPEdpc3Q+IHtcbiAgICBsZXQgcGFyYW1zITogSHR0cFBhcmFtcztcbiAgICBpZiAodGhpcy5pc09BdXRoUHJvdmlkZWQoKSkge1xuICAgICAgcGFyYW1zID0gbmV3IEh0dHBQYXJhbXMoKS5zZXQoJ2NsaWVudF9pZCcsIHRoaXMuX29wdGlvbnMuY2xpZW50SWQpLnNldCgnY2xpZW50X3NlY3JldCcsIHRoaXMuX29wdGlvbnMuY2xpZW50U2VjcmV0KTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuZmV0Y2hGaWxlKGBodHRwczovL2FwaS5naXRodWIuY29tL2dpc3RzLyR7aWR9YCwgeyBwYXJhbXMsIHJlc3BvbnNlVHlwZTogJ2pzb24nIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBjb2RlIGJ5IFVSTFxuICAgKiBAcGFyYW0gdXJsIEZpbGUgcmF3IGxpbmtcbiAgICovXG4gIGdldENvZGVGcm9tVXJsKHVybDogc3RyaW5nKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICByZXR1cm4gdGhpcy5mZXRjaEZpbGUodXJsLCB7IHJlc3BvbnNlVHlwZTogJ3RleHQnIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrIGlmIE9BdXRoIG9wdGlvbiBpcyBwcm92aWRlZFxuICAgKi9cbiAgcHJpdmF0ZSBpc09BdXRoUHJvdmlkZWQoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuICEhdGhpcy5fb3B0aW9ucyAmJiAhIXRoaXMuX29wdGlvbnMuY2xpZW50SWQgJiYgISF0aGlzLl9vcHRpb25zLmNsaWVudFNlY3JldDtcbiAgfVxuXG4gIHByaXZhdGUgZmV0Y2hGaWxlKHVybDogc3RyaW5nLCBvcHRpb25zOiBhbnkpOiBPYnNlcnZhYmxlPGFueT4ge1xuICAgIC8vIENoZWNrIGlmIFVSTCBpcyB2YWxpZFxuICAgIGlmIChpc1VybCh1cmwpKSB7XG4gICAgICByZXR1cm4gdGhpcy5faHR0cC5nZXQodXJsLCBvcHRpb25zKS5waXBlKFxuICAgICAgICAvLyBDYXRjaCByZXNwb25zZVxuICAgICAgICBwdWJsaXNoUmVwbGF5KDEpLFxuICAgICAgICByZWZDb3VudCgpLFxuICAgICAgICBjYXRjaEVycm9yKChlcnI6IEVycm9yKSA9PiB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcignW05neEhpZ2hsaWdodF06IFVuYWJsZSB0byBmZXRjaCB0aGUgVVJMIScsIGVyci5tZXNzYWdlKTtcbiAgICAgICAgICByZXR1cm4gRU1QVFk7XG4gICAgICAgIH0pXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gRU1QVFk7XG4gIH1cblxufVxuXG5mdW5jdGlvbiBpc1VybCh1cmw6IHN0cmluZykge1xuICBjb25zdCByZWdFeHAgPSAvKGZ0cHxodHRwfGh0dHBzKTpcXC9cXC8oXFx3Kzp7MCwxfVxcdypAKT8oXFxTKykoOlswLTldKyk/KFxcL3xcXC8oW1xcdyMhOi4/Kz0mJUAhXFwtXFwvXSkpPy87XG4gIHJldHVybiByZWdFeHAudGVzdCh1cmwpO1xufVxuIl19