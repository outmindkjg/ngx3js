(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common/http'), require('ngx-highlightjs'), require('rxjs'), require('rxjs/operators')) :
    typeof define === 'function' && define.amd ? define('ngx-highlightjs/plus', ['exports', '@angular/core', '@angular/common/http', 'ngx-highlightjs', 'rxjs', 'rxjs/operators'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory((global['ngx-highlightjs'] = global['ngx-highlightjs'] || {}, global['ngx-highlightjs'].plus = {}), global.ng.core, global.ng.common.http, global['ngx-highlightjs'], global.rxjs, global.rxjs.operators));
}(this, (function (exports, i0, i1, ngxHighlightjs, rxjs, operators) { 'use strict';

    function _interopNamespace(e) {
        if (e && e.__esModule) return e;
        var n = Object.create(null);
        if (e) {
            Object.keys(e).forEach(function (k) {
                if (k !== 'default') {
                    var d = Object.getOwnPropertyDescriptor(e, k);
                    Object.defineProperty(n, k, d.get ? d : {
                        enumerable: true,
                        get: function () {
                            return e[k];
                        }
                    });
                }
            });
        }
        n['default'] = e;
        return Object.freeze(n);
    }

    var i0__namespace = /*#__PURE__*/_interopNamespace(i0);
    var i1__namespace = /*#__PURE__*/_interopNamespace(i1);

    var GIST_OPTIONS = new i0.InjectionToken('GIST_OPTIONS');

    var CodeLoader = /** @class */ (function () {
        function CodeLoader(_http, _options) {
            this._http = _http;
            this._options = _options;
        }
        /**
         * Get plus code
         * @param id Gist ID
         */
        CodeLoader.prototype.getCodeFromGist = function (id) {
            var params;
            if (this.isOAuthProvided()) {
                params = new i1.HttpParams().set('client_id', this._options.clientId).set('client_secret', this._options.clientSecret);
            }
            return this.fetchFile("https://api.github.com/gists/" + id, { params: params, responseType: 'json' });
        };
        /**
         * Get code by URL
         * @param url File raw link
         */
        CodeLoader.prototype.getCodeFromUrl = function (url) {
            return this.fetchFile(url, { responseType: 'text' });
        };
        /**
         * Check if OAuth option is provided
         */
        CodeLoader.prototype.isOAuthProvided = function () {
            return !!this._options && !!this._options.clientId && !!this._options.clientSecret;
        };
        CodeLoader.prototype.fetchFile = function (url, options) {
            // Check if URL is valid
            if (isUrl(url)) {
                return this._http.get(url, options).pipe(
                // Catch response
                operators.publishReplay(1), operators.refCount(), operators.catchError(function (err) {
                    console.error('[NgxHighlight]: Unable to fetch the URL!', err.message);
                    return rxjs.EMPTY;
                }));
            }
            return rxjs.EMPTY;
        };
        return CodeLoader;
    }());
    CodeLoader.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function CodeLoader_Factory() { return new CodeLoader(i0__namespace.ɵɵinject(i1__namespace.HttpClient), i0__namespace.ɵɵinject(GIST_OPTIONS, 8)); }, token: CodeLoader, providedIn: "root" });
    CodeLoader.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    CodeLoader.ctorParameters = function () { return [
        { type: i1.HttpClient },
        { type: undefined, decorators: [{ type: i0.Optional }, { type: i0.Inject, args: [GIST_OPTIONS,] }] }
    ]; };
    function isUrl(url) {
        var regExp = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
        return regExp.test(url);
    }

    var GistDirective = /** @class */ (function () {
        function GistDirective(_loader) {
            this._loader = _loader;
            this.gistLoad = new i0.EventEmitter();
        }
        Object.defineProperty(GistDirective.prototype, "gist", {
            set: function (value) {
                var _this = this;
                if (value) {
                    this._loader.getCodeFromGist(value).subscribe(function (gist) { return _this.gistLoad.emit(gist); });
                }
            },
            enumerable: false,
            configurable: true
        });
        return GistDirective;
    }());
    GistDirective.decorators = [
        { type: i0.Directive, args: [{
                    selector: '[gist]'
                },] }
    ];
    GistDirective.ctorParameters = function () { return [
        { type: CodeLoader }
    ]; };
    GistDirective.propDecorators = {
        gist: [{ type: i0.Input }],
        gistLoad: [{ type: i0.Output }]
    };
    var GistFilePipe = /** @class */ (function () {
        function GistFilePipe() {
        }
        GistFilePipe.prototype.transform = function (gist, fileName) {
            return (gist && gist.files && gist.files[fileName]) ? gist.files[fileName].content : null;
        };
        return GistFilePipe;
    }());
    GistFilePipe.decorators = [
        { type: i0.Pipe, args: [{
                    name: 'gistFile'
                },] }
    ];

    var CodeFromUrlPipe = /** @class */ (function () {
        function CodeFromUrlPipe(_loader) {
            this._loader = _loader;
        }
        CodeFromUrlPipe.prototype.transform = function (url) {
            return this._loader.getCodeFromUrl(url);
        };
        return CodeFromUrlPipe;
    }());
    CodeFromUrlPipe.decorators = [
        { type: i0.Pipe, args: [{
                    name: 'codeFromUrl'
                },] }
    ];
    CodeFromUrlPipe.ctorParameters = function () { return [
        { type: CodeLoader }
    ]; };

    var HighlightPlusModule = /** @class */ (function () {
        function HighlightPlusModule() {
        }
        return HighlightPlusModule;
    }());
    HighlightPlusModule.decorators = [
        { type: i0.NgModule, args: [{
                    imports: [
                        ngxHighlightjs.HighlightModule,
                        i1.HttpClientModule
                    ],
                    declarations: [
                        GistDirective,
                        GistFilePipe,
                        CodeFromUrlPipe
                    ],
                    exports: [
                        ngxHighlightjs.HighlightModule,
                        GistDirective,
                        GistFilePipe,
                        CodeFromUrlPipe
                    ]
                },] }
    ];

    /**
     * Generated bundle index. Do not edit.
     */

    exports.CodeFromUrlPipe = CodeFromUrlPipe;
    exports.CodeLoader = CodeLoader;
    exports.GIST_OPTIONS = GIST_OPTIONS;
    exports.GistDirective = GistDirective;
    exports.GistFilePipe = GistFilePipe;
    exports.HighlightPlusModule = HighlightPlusModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ngx-highlightjs-plus.umd.js.map
