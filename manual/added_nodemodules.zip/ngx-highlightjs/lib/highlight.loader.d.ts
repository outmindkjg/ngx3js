import { Observable } from 'rxjs';
import { HighlightLibrary, HighlightOptions } from './highlight.model';
import * as ɵngcc0 from '@angular/core';
export declare class HighlightLoader {
    private _options;
    private readonly _ready;
    readonly ready: Observable<HighlightLibrary>;
    constructor(doc: any, platformId: object, _options: HighlightOptions);
    /**
     * Lazy-Load highlight.js library
     */
    private _loadLibrary;
    /**
     * Lazy-load highlight.js languages
     */
    private _loadLanguages;
    /**
     * Import highlight.js core library
     */
    private loadCoreLibrary;
    /**
     * Import highlight.js library with all languages
     */
    private loadFullLibrary;
    /**
     * Import line numbers library
     */
    private loadLineNumbers;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<HighlightLoader, [null, null, { optional: true; }]>;
}

//# sourceMappingURL=highlight.loader.d.ts.map