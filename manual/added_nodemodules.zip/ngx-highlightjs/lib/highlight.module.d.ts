import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './highlight';
export declare class HighlightModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<HighlightModule, [typeof ɵngcc1.Highlight], never, [typeof ɵngcc1.Highlight]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<HighlightModule>;
}

//# sourceMappingURL=highlight.module.d.ts.map