import * as i0 from '@angular/core';
import { InjectionToken, Injectable, Inject, PLATFORM_ID, Optional, EventEmitter, SecurityContext, Directive, ElementRef, Input, Output, NgModule } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { BehaviorSubject, EMPTY, throwError, from, zip, animationFrameScheduler } from 'rxjs';
import { filter, map, take, switchMap, tap, catchError } from 'rxjs/operators';
import * as i1 from '@angular/common';
import { isPlatformBrowser, DOCUMENT } from '@angular/common';

const HIGHLIGHT_OPTIONS = new InjectionToken('HIGHLIGHT_OPTIONS');

// @dynamic
class HighlightLoader {
    constructor(doc, platformId, _options) {
        this._options = _options;
        // Stream that emits when hljs library is loaded and ready to use
        this._ready = new BehaviorSubject(null);
        this.ready = this._ready.asObservable().pipe(filter((hljs) => !!hljs), map((hljs) => hljs), take(1));
        // Check if hljs is already available
        if (isPlatformBrowser(platformId) && doc.defaultView.hljs) {
            this._ready.next(doc.defaultView.hljs);
        }
        else {
            // Load hljs library
            this._loadLibrary().pipe(switchMap((hljs) => {
                if (this._options && this._options.lineNumbersLoader) {
                    // Make hljs available on window object (required for the line numbers library)
                    doc.defaultView.hljs = hljs;
                    // Load line numbers library
                    return this.loadLineNumbers().pipe(tap(() => this._ready.next(hljs)));
                }
                else {
                    this._ready.next(hljs);
                    return EMPTY;
                }
            }), catchError((e) => {
                console.error('[HLJS] ', e);
                return EMPTY;
            })).subscribe();
        }
    }
    /**
     * Lazy-Load highlight.js library
     */
    _loadLibrary() {
        if (this._options) {
            if (this._options.fullLibraryLoader && this._options.coreLibraryLoader) {
                return throwError('The full library and the core library were imported, only one of them should be imported!');
            }
            if (this._options.fullLibraryLoader && this._options.languages) {
                return throwError('The highlighting languages were imported they are not needed!');
            }
            if (this._options.coreLibraryLoader && !this._options.languages) {
                return throwError('The highlighting languages were not imported!');
            }
            if (!this._options.coreLibraryLoader && this._options.languages) {
                return throwError('The core library was not imported!');
            }
            if (this._options.fullLibraryLoader) {
                return this.loadFullLibrary();
            }
            if (this._options.coreLibraryLoader && this._options.languages && Object.keys(this._options.languages).length) {
                return this.loadCoreLibrary().pipe(switchMap((hljs) => this._loadLanguages(hljs)));
            }
        }
        return throwError('Highlight.js library was not imported!');
    }
    /**
     * Lazy-load highlight.js languages
     */
    _loadLanguages(hljs) {
        const languages = Object.entries(this._options.languages).map(([langName, langLoader]) => importModule(langLoader()).pipe(tap((langFunc) => hljs.registerLanguage(langName, langFunc))));
        return zip(...languages).pipe(map(() => hljs));
    }
    /**
     * Import highlight.js core library
     */
    loadCoreLibrary() {
        return importModule(this._options.coreLibraryLoader());
    }
    /**
     * Import highlight.js library with all languages
     */
    loadFullLibrary() {
        return importModule(this._options.fullLibraryLoader());
    }
    /**
     * Import line numbers library
     */
    loadLineNumbers() {
        return importModule(this._options.lineNumbersLoader());
    }
}
HighlightLoader.ɵprov = i0.ɵɵdefineInjectable({ factory: function HighlightLoader_Factory() { return new HighlightLoader(i0.ɵɵinject(i1.DOCUMENT), i0.ɵɵinject(i0.PLATFORM_ID), i0.ɵɵinject(HIGHLIGHT_OPTIONS, 8)); }, token: HighlightLoader, providedIn: "root" });
HighlightLoader.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
HighlightLoader.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [DOCUMENT,] }] },
    { type: Object, decorators: [{ type: Inject, args: [PLATFORM_ID,] }] },
    { type: undefined, decorators: [{ type: Optional }, { type: Inject, args: [HIGHLIGHT_OPTIONS,] }] }
];
/**
 * Map loader response to module object
 */
const importModule = (moduleLoader) => {
    return from(moduleLoader).pipe(filter((module) => !!module && !!module.default), map((module) => module.default));
};
const ɵ0 = importModule;

class HighlightJS {
    constructor(_loader, options) {
        this._loader = _loader;
        this._hljs = null;
        // Load highlight.js library on init
        _loader.ready.pipe().subscribe((hljs) => {
            this._hljs = hljs;
            if (options && options.config) {
                // Set global config if present
                hljs.configure(options.config);
                if (hljs.listLanguages().length < 1) {
                    console.error('[HighlightJS]: No languages were registered!');
                }
            }
        });
    }
    // A reference for hljs library
    get hljs() {
        return this._hljs;
    }
    /**
     * Core highlighting function.
     * @param name Accepts a language name, or an alias
     * @param value A string with the code to highlight.
     * @param ignore_illegals When present and evaluates to a true value, forces highlighting to finish
     * even in case of detecting illegal syntax for the language instead of throwing an exception.
     * @param continuation An optional mode stack representing unfinished parsing.
     * When present, the function will restart parsing from this state instead of initializing a new one
     */
    highlight(name, value, ignore_illegals, continuation) {
        return this._loader.ready.pipe(map((hljs) => hljs.highlight(name, value, ignore_illegals, continuation)));
    }
    /**
     * Highlighting with language detection.
     * @param value Accepts a string with the code to highlight
     * @param languageSubset An optional array of language names and aliases restricting detection to only those languages.
     * The subset can also be set with configure, but the local parameter overrides the option if set.
     */
    highlightAuto(value, languageSubset) {
        return this._loader.ready.pipe(map((hljs) => hljs.highlightAuto(value, languageSubset)));
    }
    /**
     * Post-processing of the highlighted markup.
     * Currently consists of replacing indentation TAB characters and using <br> tags instead of new-line characters.
     * Options are set globally with configure.
     * @param value Accepts a string with the highlighted markup
     */
    fixMarkup(value) {
        return this._loader.ready.pipe(map((hljs) => hljs.fixMarkup(value)));
    }
    /**
     * Applies highlighting to a DOM node containing code.
     * The function uses language detection by default but you can specify the language in the class attribute of the DOM node.
     * See the class reference for all available language names and aliases.
     * @param block The element to apply highlight on.
     */
    highlightBlock(block) {
        return this._loader.ready.pipe(map((hljs) => hljs.highlightBlock(block)));
    }
    /**
     * Configures global options:
     * @param config HighlightJs configuration argument
     */
    configure(config) {
        return this._loader.ready.pipe(map((hljs) => hljs.configure(config)));
    }
    /**
     * Applies highlighting to all <pre><code>..</code></pre> blocks on a page.
     */
    initHighlighting() {
        return this._loader.ready.pipe(map((hljs) => hljs.initHighlighting()));
    }
    /**
     * Adds new language to the library under the specified name. Used mostly internally.
     * @param name A string with the name of the language being registered
     * @param language A function that returns an object which represents the language definition.
     * The function is passed the hljs object to be able to use common regular expressions defined within it.
     */
    registerLanguage(name, language) {
        return this._loader.ready.pipe(tap((hljs) => hljs.registerLanguage(name, language)));
    }
    /**
     * @return The languages names list.
     */
    listLanguages() {
        return this._loader.ready.pipe(map((hljs) => hljs.listLanguages()));
    }
    /**
     * Looks up a language by name or alias.
     * @param name Language name
     * @return The language object if found, undefined otherwise.
     */
    getLanguage(name) {
        return this._loader.ready.pipe(map((hljs) => hljs.getLanguage(name)));
    }
    /**
     * Display line numbers
     * @param el Code element
     */
    lineNumbersBlock(el) {
        return this._loader.ready.pipe(filter((hljs) => !!hljs.lineNumbersBlock), tap((hljs) => hljs.lineNumbersBlock(el)));
    }
}
HighlightJS.ɵprov = i0.ɵɵdefineInjectable({ factory: function HighlightJS_Factory() { return new HighlightJS(i0.ɵɵinject(HighlightLoader), i0.ɵɵinject(HIGHLIGHT_OPTIONS, 8)); }, token: HighlightJS, providedIn: "root" });
HighlightJS.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
HighlightJS.ctorParameters = () => [
    { type: HighlightLoader },
    { type: undefined, decorators: [{ type: Optional }, { type: Inject, args: [HIGHLIGHT_OPTIONS,] }] }
];

class Highlight {
    constructor(el, _hljs, _sanitizer, _options) {
        this._hljs = _hljs;
        this._sanitizer = _sanitizer;
        this._options = _options;
        // Stream that emits when code string is highlighted
        this.highlighted = new EventEmitter();
        this._nativeElement = el.nativeElement;
    }
    ngOnChanges(changes) {
        if (this.code &&
            changes.code &&
            typeof changes.code.currentValue !== 'undefined' &&
            changes.code.currentValue !== changes.code.previousValue) {
            this.highlightElement(this.code, this.languages);
        }
    }
    /**
     * Highlighting with language detection and fix markup.
     * @param code Accepts a string with the code to highlight
     * @param languages An optional array of language names and aliases restricting detection to only those languages.
     * The subset can also be set with configure, but the local parameter overrides the option if set.
     */
    highlightElement(code, languages) {
        // Set code text before highlighting
        this.setTextContent(code);
        this._hljs.highlightAuto(code, languages).subscribe((res) => {
            // Set highlighted code
            this.setInnerHTML(res.value);
            // Check if user want to show line numbers
            if (this.lineNumbers && this._options && this._options.lineNumbersLoader) {
                this.addLineNumbers();
            }
            // Forward highlight response to the highlighted output
            this.highlighted.emit(res);
        });
    }
    addLineNumbers() {
        // Clean up line numbers observer
        this.destroyLineNumbersObserver();
        animationFrameScheduler.schedule(() => {
            // Add line numbers
            this._hljs.lineNumbersBlock(this._nativeElement).subscribe();
            // If lines count is 1, the line numbers library will not add numbers
            // Observe changes to add 'hljs-line-numbers' class only when line numbers is added to the code element
            this._lineNumbersObs = new MutationObserver(() => {
                if (this._nativeElement.firstElementChild && this._nativeElement.firstElementChild.tagName.toUpperCase() === 'TABLE') {
                    this._nativeElement.classList.add('hljs-line-numbers');
                }
                this.destroyLineNumbersObserver();
            });
            this._lineNumbersObs.observe(this._nativeElement, { childList: true });
        });
    }
    destroyLineNumbersObserver() {
        if (this._lineNumbersObs) {
            this._lineNumbersObs.disconnect();
            this._lineNumbersObs = null;
        }
    }
    setTextContent(content) {
        animationFrameScheduler.schedule(() => this._nativeElement.textContent = content);
    }
    setInnerHTML(content) {
        animationFrameScheduler.schedule(() => this._nativeElement.innerHTML = this._sanitizer.sanitize(SecurityContext.HTML, content) || '');
    }
}
Highlight.decorators = [
    { type: Directive, args: [{
                host: {
                    '[class.hljs]': 'true'
                },
                selector: '[highlight]'
            },] }
];
Highlight.ctorParameters = () => [
    { type: ElementRef },
    { type: HighlightJS },
    { type: DomSanitizer },
    { type: undefined, decorators: [{ type: Optional }, { type: Inject, args: [HIGHLIGHT_OPTIONS,] }] }
];
Highlight.propDecorators = {
    code: [{ type: Input, args: ['highlight',] }],
    languages: [{ type: Input }],
    lineNumbers: [{ type: Input }],
    highlighted: [{ type: Output }]
};

class HighlightModule {
}
HighlightModule.decorators = [
    { type: NgModule, args: [{
                declarations: [Highlight],
                exports: [Highlight]
            },] }
];

/**
 * Generated bundle index. Do not edit.
 */

export { HIGHLIGHT_OPTIONS, Highlight, HighlightJS, HighlightLoader, HighlightModule, ɵ0 };
//# sourceMappingURL=ngx-highlightjs.js.map
