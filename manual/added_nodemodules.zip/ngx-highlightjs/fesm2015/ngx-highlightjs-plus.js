import * as i0 from '@angular/core';
import { InjectionToken, Injectable, Optional, Inject, EventEmitter, Directive, Input, Output, Pipe, NgModule } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpParams, HttpClient, HttpClientModule } from '@angular/common/http';
import { HighlightModule } from 'ngx-highlightjs';
import { EMPTY } from 'rxjs';
import { publishReplay, refCount, catchError } from 'rxjs/operators';

const GIST_OPTIONS = new InjectionToken('GIST_OPTIONS');

class CodeLoader {
    constructor(_http, _options) {
        this._http = _http;
        this._options = _options;
    }
    /**
     * Get plus code
     * @param id Gist ID
     */
    getCodeFromGist(id) {
        let params;
        if (this.isOAuthProvided()) {
            params = new HttpParams().set('client_id', this._options.clientId).set('client_secret', this._options.clientSecret);
        }
        return this.fetchFile(`https://api.github.com/gists/${id}`, { params, responseType: 'json' });
    }
    /**
     * Get code by URL
     * @param url File raw link
     */
    getCodeFromUrl(url) {
        return this.fetchFile(url, { responseType: 'text' });
    }
    /**
     * Check if OAuth option is provided
     */
    isOAuthProvided() {
        return !!this._options && !!this._options.clientId && !!this._options.clientSecret;
    }
    fetchFile(url, options) {
        // Check if URL is valid
        if (isUrl(url)) {
            return this._http.get(url, options).pipe(
            // Catch response
            publishReplay(1), refCount(), catchError((err) => {
                console.error('[NgxHighlight]: Unable to fetch the URL!', err.message);
                return EMPTY;
            }));
        }
        return EMPTY;
    }
}
CodeLoader.ɵprov = i0.ɵɵdefineInjectable({ factory: function CodeLoader_Factory() { return new CodeLoader(i0.ɵɵinject(i1.HttpClient), i0.ɵɵinject(GIST_OPTIONS, 8)); }, token: CodeLoader, providedIn: "root" });
CodeLoader.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
CodeLoader.ctorParameters = () => [
    { type: HttpClient },
    { type: undefined, decorators: [{ type: Optional }, { type: Inject, args: [GIST_OPTIONS,] }] }
];
function isUrl(url) {
    const regExp = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
    return regExp.test(url);
}

class GistDirective {
    constructor(_loader) {
        this._loader = _loader;
        this.gistLoad = new EventEmitter();
    }
    set gist(value) {
        if (value) {
            this._loader.getCodeFromGist(value).subscribe((gist) => this.gistLoad.emit(gist));
        }
    }
}
GistDirective.decorators = [
    { type: Directive, args: [{
                selector: '[gist]'
            },] }
];
GistDirective.ctorParameters = () => [
    { type: CodeLoader }
];
GistDirective.propDecorators = {
    gist: [{ type: Input }],
    gistLoad: [{ type: Output }]
};
class GistFilePipe {
    transform(gist, fileName) {
        return (gist && gist.files && gist.files[fileName]) ? gist.files[fileName].content : null;
    }
}
GistFilePipe.decorators = [
    { type: Pipe, args: [{
                name: 'gistFile'
            },] }
];

class CodeFromUrlPipe {
    constructor(_loader) {
        this._loader = _loader;
    }
    transform(url) {
        return this._loader.getCodeFromUrl(url);
    }
}
CodeFromUrlPipe.decorators = [
    { type: Pipe, args: [{
                name: 'codeFromUrl'
            },] }
];
CodeFromUrlPipe.ctorParameters = () => [
    { type: CodeLoader }
];

class HighlightPlusModule {
}
HighlightPlusModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    HighlightModule,
                    HttpClientModule
                ],
                declarations: [
                    GistDirective,
                    GistFilePipe,
                    CodeFromUrlPipe
                ],
                exports: [
                    HighlightModule,
                    GistDirective,
                    GistFilePipe,
                    CodeFromUrlPipe
                ]
            },] }
];

/**
 * Generated bundle index. Do not edit.
 */

export { CodeFromUrlPipe, CodeLoader, GIST_OPTIONS, GistDirective, GistFilePipe, HighlightPlusModule };
//# sourceMappingURL=ngx-highlightjs-plus.js.map
