export declare class HighlightPlusModule {
}
