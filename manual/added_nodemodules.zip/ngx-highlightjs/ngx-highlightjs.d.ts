/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';

//# sourceMappingURL=ngx-highlightjs.d.ts.map