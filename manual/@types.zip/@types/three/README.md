# Installation
> `npm install --save @types/three`

# Summary
This package contains type definitions for three (https://threejs.org/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/three.

### Additional Details
 * Last updated: Mon, 05 Jul 2021 18:31:18 GMT
 * Dependencies: none
 * Global values: `THREE`

# Credits
These definitions were written by [Josh Ellis](https://github.com/joshuaellis), and [Nathan Bierema](https://github.com/Methuselah96).
