export namespace DataUtils {
    function toHalfFloat(val: number): number;
}
