import { BufferGeometry } from '../../../src/Three';

export function UVsDebug(geometry: BufferGeometry, size: number): HTMLCanvasElement;
