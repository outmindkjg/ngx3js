import { BufferGeometry, Vector3 } from '../../../src/Three';

export class ConvexGeometry extends BufferGeometry {
    constructor(points: Vector3[]);
}
