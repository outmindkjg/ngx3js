declare namespace _default {
    const lights_fragment_begin: string;
    const lights_pars_begin: string;
}

export default _default;
