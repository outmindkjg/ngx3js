import { WebGLRenderer } from '../../../src/Three';

export namespace ARButton {
    function createButton(renderer: WebGLRenderer, sessionInit?: any): HTMLElement;
}
