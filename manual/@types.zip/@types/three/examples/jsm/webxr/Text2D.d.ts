import { Mesh } from '../../../src/Three';

export function createText(message: string, height: number): Mesh;
