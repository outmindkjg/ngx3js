// Add helpers needed in samples here.
// Usable through `helpers[name]`.
export {color, getHoverColor} from '../../dist/helpers.esm';

