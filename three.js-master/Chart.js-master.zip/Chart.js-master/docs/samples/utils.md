# Utils

## Disclaimer
The Utils file contains multiple helper functions that the chart.js sample pages use to generate charts.
These functions are subject to change, including but not limited to breaking changes without prior notice.

Because of this please don't rely on this file in production environments.

## Functions

<<< @/docs/scripts/utils.js

[File on github](https://github.com/chartjs/Chart.js/blob/master/docs/scripts/utils.js)

